﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SAEP.Classes;
using System.Data.SqlClient;

namespace SAEP
{
    public partial class Form3 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\SAEP\SAEP\Database1.mdf;Integrated Security=True;Connect Timeout=30");
        public Form3()
        {
            InitializeComponent();
        }

        public Form3(string texto)
        {
            InitializeComponent();
            var idcarro = texto;
            con.Open();
            String query = "SELECT * FROM automoveis WHERE Id = @Id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = idcarro;
            cmd.CommandType = CommandType.Text;
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                lblCarro.Text = rd["modelo"].ToString();
                rd.Close();
            }
            con.Close();
        }

        public void CarregaDGV()
        {
            Cliente saldo = new Cliente();
            dgvCliente.DataSource = saldo.ListaClientes();
        }

        public void CarregaDGVCon()
        {
            Concessionaria saldo = new Concessionaria();
            dgvConcessionaria.DataSource = saldo.ListaConcessionarias();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            CarregaDGV();
            CarregaDGVCon();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCliente.Text == "" || txtConcessionaria.Text == "")
            {
                MessageBox.Show("Para seguir é necessario preencher os campos");
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM automoveis WHERE modelo = @modelo", con);
                cmd.Parameters.AddWithValue("@modelo", SqlDbType.Int).Value = lblCarro.Text;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Venda Efetuada com sucesso!");
                txtConcessionaria.Text = "";
                txtCliente.Text = "";
            }
        }
    }
}
