﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace SAEP.Classes
{
    internal class Concessionaria
    {
        public int id { get; set; }
        public string concessionária { get; set; }

        public Concessionaria(int id, string nome)
        {
            this.id = id;
            this.concessionária = nome;

        }

        public Concessionaria()
        {

        }

        public List<Concessionaria> ListaConcessionarias()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Concessionaria> li = new List<Concessionaria>();
            string sql = "SELECT * FROM concessionarias";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Concessionaria m = new Concessionaria();
                m.id = (int)dr["id"];
                m.concessionária = dr["concessionária"].ToString();
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }
    }
}
