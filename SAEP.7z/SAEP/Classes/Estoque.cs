﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAEP.Classes;
using System.Data.SqlClient;

namespace SAEP.Classes
{
    internal class Estoque
    {
        public int id { get; set; }
        public string modelo { get; set; }
        public decimal preço { get; set; }
        public int quantidade { get; set; }

        public Estoque(int id, string modelo, decimal preço, int quantidade)
        {
            this.id = id;
            this.modelo = modelo;
            this.preço = preço;
            this.quantidade = quantidade;
        }

        public Estoque()
        {
        }

        public List<Estoque> ListaArea1()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=1 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea2()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=2 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea3()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=3 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea4()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=4 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea5()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=5 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea6()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=6 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea7()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=7 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea8()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=8 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea9()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=9 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea10()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=10 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea11()
        {
            SqlConnection con = Conexao.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "select automoveis.Id,automoveis.modelo,automoveis.preço,alocacao.quantidade from alocacao,automoveis where alocacao.area=11 and alocacao.automovel=automoveis.Id";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.id = (int)dr["Id"];
                m.modelo = Convert.ToString(dr["modelo"]);
                m.preço = (decimal)dr["preço"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            Conexao.FecharConexao();
            dr.Close();
            return li;
        }
    }
}
